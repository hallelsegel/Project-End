﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;

namespace WPFclient
{
    /// <summary>
    /// Interaction logic for inRoom.xaml
    /// </summary>
    public partial class inRoom : Window
    {
        bool _isAdmin;
        ClientBody cl; //shared class 
        WindowCollection windows;
        public inRoom(bool isAdmin)
        {
            windows = WPFclient.App.Current.Windows; //for waitForMsg
            _isAdmin = isAdmin;
            cl = (ClientBody)WPFclient.App.Current.Properties["client"];
            InitializeComponent();
            if (this._isAdmin) joinerExit.Visibility = Visibility.Hidden;
            else
            {
                adminExitButton.Visibility = Visibility.Hidden;
                adminStartButton.Visibility = Visibility.Hidden;
            }
            UserName.Content = cl._username;
            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            Thread t = new Thread(waitForMsg);
            t.Start();
        }
        private void waitForMsg()
        {
            bool _inRoom = true;
            while (_inRoom)
            {
                byte[] rcv = new byte[3];
                cl._clientStream.Read(rcv, 0, rcv.Length);
                string answer = System.Text.Encoding.UTF8.GetString(rcv, 0, rcv.Length);
                if (answer == "108") //108 == users in room answer from server (this means someone joined and the list should be updated)
                    rcvGetUsers();
                else if ((answer == "112" && !_isAdmin) || answer == "116") //112 == answer to leaveRoom from server, 116 == admin has closed the room
                {
                    if (answer == "112") cl._clientStream.Read(rcv, 0, 1); //another byte is send to indicate success or failure of leave room
                    bool success = BitConverter.ToBoolean(rcv, 0);
                    if (answer == "116" || success) //only leave room needs a success flag
                    {//move back to mainMenu
                        _inRoom = false;
                        int i;
                        for (i = 0; i < windows.Count; i++) if (windows[i].ToString() == "WPFclient.mainMenu") break;
                        if (i == windows.Count) //if there is mainMenu open already
                        {
                            mainMenu m = new mainMenu(); //else create one and open it
                            m.Show();
                        }
                        else windows[i].Show();
                        this.Hide();
                    }
                }
                else if (answer == "118") //118 == game started, first question was send
                {
                    int i;
                    for (i = 0; i < windows.Count; i++) if (windows[i].ToString() == "WPFclient.game") break;
                    if (i == windows.Count) //if there is mainMenu open already
                    {
                        game g = new game(); //else create one and open it
                        g.Show();
                    }
                    else windows[i].Show();
                    this.Hide();
                    _inRoom = false;
                }
            }
        }
        private void click_game(object sender, RoutedEventArgs e)
        {//open a game
            byte[] buffer = new ASCIIEncoding().GetBytes("217"); //217 == start game
            cl._clientStream.Write(buffer, 0, buffer.Length); //send message code to server
            cl._clientStream.Flush();
        }
        private void click_mainMenu(object sender, RoutedEventArgs e)
        {//either the "leave room" or the "close room" were pressed
            byte[] buffer;
            if (_isAdmin) buffer = new ASCIIEncoding().GetBytes("215");
            else buffer = new ASCIIEncoding().GetBytes("211");
            cl._clientStream.Write(buffer, 0, buffer.Length); //send message code to server (closeRoom if admin and leaveRoom if not)
            cl._clientStream.Flush();
            //wait for the recieving function to get the answer and move to mainMenu according to that
        }
        private void rcvGetUsers()
        {/* Same code as in connectedUser, but doesn't send for it, beacuse it is sent automatically when someone joins*/
            byte[] rcv = new byte[1]; //success flag for getting users
            cl._clientStream.Read(rcv, 0, 1);
            if (System.Text.Encoding.UTF8.GetString(rcv) == "0")
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = "There are no users, the room probably closed";
                usersList.Items.Add(item);
            }
            else
            {
                int userNum = Int32.Parse(System.Text.Encoding.UTF8.GetString(rcv));
                for (int i = 0; i < userNum; i++)
                {
                    ListBoxItem item = new ListBoxItem();
                    rcv = new byte[2];
                    cl._clientStream.Read(rcv, 0, 2);
                    int nameLen = Int32.Parse(System.Text.Encoding.UTF8.GetString(rcv));
                    rcv = new byte[nameLen];
                    cl._clientStream.Read(rcv, 0, nameLen);
                    item.Content += System.Text.Encoding.UTF8.GetString(rcv);
                    usersList.Items.Add(item);
                }
            }
        }
    }
}
