﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net.Sockets;
using System.Net;

namespace WPFclient
{
    /// <summary>
    /// Interaction logic for mainMenu.xaml
    /// </summary>
    public partial class mainMenu : Window
    {
        ClientBody cl;
        public mainMenu()
        {
            cl = (ClientBody)WPFclient.App.Current.Properties["client"];
            InitializeComponent();
            UserName.Content = cl._username;
            this.Closed += new EventHandler(theWindow_Closed);
            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
        }

        private void click_logOut(object sender, RoutedEventArgs e)
        {
            byte[] buffer = new ASCIIEncoding().GetBytes("201");//when the window is closed, send the exit code
            cl._clientStream.Write(buffer, 0, buffer.Length);
            cl._clientStream.Flush();
            int windowNum = WPFclient.App.Current.Windows.Count;
            for (int i = 0, j = 0; i < windowNum;i++)
            {
                if (WPFclient.App.Current.Windows[j].ToString() != "WPFclient.mainMenu")
                {
                    WPFclient.App.Current.Windows[j].Close(); //reset the app for the last user, by closing each window (except this
                }
                else j = 1;
                cl._isConnected = false;
            }//always close [0] because it is 'popped' and leaves its place for the next one, but move to [1] when skipping this window
            MainWindow w = new MainWindow();
            w.Show();
            this.Close();
        }
                
        private void click_createRoom(object sender, RoutedEventArgs e)
        {
            int i;
            for (i = 0; i < WPFclient.App.Current.Windows.Count; i++) if (WPFclient.App.Current.Windows[i].ToString() == "WPFclient.createRoom") break;
            if (i == WPFclient.App.Current.Windows.Count) //if there is createRoom open already
            {
                createRoom c = new createRoom(); //else create one and open it
                c.Show();
            }
            else WPFclient.App.Current.Windows[i].Show();
            this.Hide();
        }

        private void click_joinRoom(object sender, RoutedEventArgs e)
        {
            int i;
            for (i = 0; i < WPFclient.App.Current.Windows.Count; i++) if (WPFclient.App.Current.Windows[i].ToString() == "WPFclient.joinRoom") break;
            if (i == WPFclient.App.Current.Windows.Count) //if there is createRoom open already
            {
                joinRoom j = new joinRoom(); //else create one and open it
                j.Show();
            }
            else WPFclient.App.Current.Windows[i].Show();
            this.Hide();
        }

        private void click_highScores(object sender, RoutedEventArgs e)
        {
            int i;
            for (i = 0; i < WPFclient.App.Current.Windows.Count; i++) if (WPFclient.App.Current.Windows[i].ToString() == "WPFclient.highScores") break;
            if (i == WPFclient.App.Current.Windows.Count) //if there is createRoom open already
            {
                highScores h = new highScores(); //else create one and open it
                h.Show();
            }
            else WPFclient.App.Current.Windows[i].Show();
            this.Hide();
        }

        private void click_personalStats(object sender, RoutedEventArgs e)
        {
            int i;
            for (i = 0; i < WPFclient.App.Current.Windows.Count; i++) if (WPFclient.App.Current.Windows[i].ToString() == "WPFclient.personalStats") break;
            if (i == WPFclient.App.Current.Windows.Count) //if there is createRoom open already
            {
                personalStats p = new personalStats(); //else create one and open it
                p.Show();
            }
            else WPFclient.App.Current.Windows[i].Show();
            this.Hide();
        }

        private void theWindow_Closed(object sender, System.EventArgs e)
        {
            if (cl._isConnected == true)
            {
                byte[] buffer = new ASCIIEncoding().GetBytes("299");//when the window is closed, send the exit code
                cl._clientStream.Write(buffer, 0, buffer.Length);
                cl._clientStream.Flush();
            }
        }
    }
}
